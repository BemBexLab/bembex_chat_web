// This file sets up a basic Socket.IO server for Next.js custom server usage.
// You must run your Next.js app with a custom Node.js server for this to work.

const { Server } = require("socket.io");

let io;

function setupSocket(server) {
  if (!io) {
    console.log("[SocketServer] 🚀 Initializing Socket.IO server...");
    io = new Server(server, {
      cors: {
        origin: '*',
        methods: ['GET', 'POST']
      }
    });

    io.on("connection", (socket) => {
      console.log("[SocketServer] ✅ New client connected, socket ID:", socket.id);

      // Identify user/admin
      socket.on("identify", ({ id, type }) => {
        socket.data.userId = id;
        socket.data.userType = type;
        socket.join(id);
        console.log("[SocketServer] 📤 User identified:", { userId: id, userType: type, socketId: socket.id });
      });

      // Join/leave conversation rooms
      socket.on("join", (room) => {
        socket.join(room);
        console.log("[SocketServer] 📍 Socket joined room:", room, "socketId:", socket.id);
      });

      socket.on("leave", (room) => {
        socket.leave(room);
        console.log("[SocketServer] 🚪 Socket left room:", room, "socketId:", socket.id);
      });

      // Forward new messages to room
      socket.on("new_message", (data) => {
        if (data.conversationId) {
          console.log("[SocketServer] 📨 Received new_message event in socket handler");
          console.log("[SocketServer] 📊 Event data:", {
            conversationId: data.conversationId,
            from: data.senderName,
            to: data.senderName, // Note: receiver name not in event
            messagePreview: data.message?.substring(0, 50)
          });
          
          // Get room info for debugging
          const room = io.sockets.adapter.rooms.get(data.conversationId);
          const roomSize = room ? room.size : 0;
          console.log("[SocketServer] 📍 Room stats:", {
            conversationId: data.conversationId,
            socketsInRoom: roomSize,
            totalConnected: io.sockets.sockets.size
          });
          
          io.to(data.conversationId).emit("new_message", data);
          console.log("[SocketServer] ✅ new_message relayed to room");
        }
      });

      socket.on("disconnect", () => {
        console.log("[SocketServer] ❌ Client disconnected, socket ID:", socket.id);
      });
    });

    console.log("[SocketServer] ✅ Socket.IO server initialized successfully");
  }
  try {
    // expose io instance on global for API routes to emit events
    global.__io = io;
    console.log("[SocketServer] ✅ Exposed Socket.IO instance to global.__io");
  } catch (e) {
    console.error("[SocketServer] ❌ Failed to expose Socket.IO instance to global:", e);
  }
  return io;
}

module.exports = { setupSocket };
