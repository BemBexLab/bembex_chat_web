import { io, Socket } from "socket.io-client";

let socket: Socket | null = null;

export function connectSocket(token: string, userId: string, userType: string) {
	console.log("[Socket] connectSocket called - current socket state:", socket?.connected ? "CONNECTED" : socket ? "DISCONNECTED" : "NULL");
	
	// If socket exists and is connected, just return it
	if (socket && socket.connected) {
		console.log("[Socket] ✅ Socket already connected, returning existing socket");
		return socket;
	}
	
	// If socket exists but disconnected, try to reconnect
	if (socket && !socket.connected) {
		console.log("[Socket] Socket was disconnected, attempting to reconnect...");
		socket.connect();
		return socket;
	}

	// Create new socket connection
	if (!socket) {
		console.log("[Socket] 📡 Creating NEW socket connection for user:", userId, "type:", userType);
		socket = io(typeof window !== "undefined" ? window.location.origin : "", {
			transports: ["websocket"],
			auth: { token },
			reconnection: true,
			reconnectionDelay: 1000,
			reconnectionDelayMax: 5000,
			reconnectionAttempts: 5,
			forceNew: false,
		});

		socket.on("connect", () => {
			console.log("[Socket] ✅ Connected! Socket ID:", socket?.id);
			socket?.emit("identify", { id: userId, type: userType });
			console.log("[Socket] 📤 Sent identify event with userId:", userId, "type:", userType);
		});

		socket.on("disconnect", (reason) => {
			console.log("[Socket] ❌ Disconnected - Reason:", reason);
			console.log("[Socket] Will attempt to reconnect on next activity...");
		});

		socket.on("reconnect", () => {
			console.log("[Socket] 🔄 Reconnected!");
			socket?.emit("identify", { id: userId, type: userType });
		});

		socket.on("connect_error", (error) => {
			console.error("[Socket] 🔴 Connection error:", error);
		});

		// Immediate suspension handling
		socket.on('user_suspended', async (data: any) => {
			console.log("[Socket] User suspended event received");
			try {
				await fetch('/api/user/logout', { method: 'POST' });
			} catch (e) {
				// ignore
			}

			try { localStorage.removeItem('auth'); } catch (e) {}
			try { localStorage.removeItem('admin_auth'); } catch (e) {}
			disconnectSocket();
			alert(data?.message || 'Your account has been suspended');
			window.location.href = '/login';
		});

		// Force logout event
		socket.on('force_logout', async (data: any) => {
			console.log("[Socket] Force logout event received");
			try {
				await fetch('/api/user/logout', { method: 'POST' });
			} catch (e) {}
			try { localStorage.removeItem('auth'); } catch (e) {}
			try { localStorage.removeItem('admin_auth'); } catch (e) {}
			disconnectSocket();
			alert(data?.message || 'You have been logged out by an administrator');
			window.location.href = '/login';
		});
	}
	return socket;
}

export function disconnectSocket() {
	if (socket) {
		console.log("[Socket] 🛑 Forcing disconnect and cleanup");
		socket.disconnect();
		socket = null;
	}
}

export function getSocket() {
	if (socket && !socket.connected) {
		console.log("[Socket] ⚠️ getSocket called but socket is disconnected. Attempting to reconnect...");
		socket.connect();
	}
	return socket;
}
