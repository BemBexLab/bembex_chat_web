import mongoose from 'mongoose';

const activitySchema = new mongoose.Schema(
  {
    type: {
      type: String,
      enum: ['user_login', 'user_logout'],
      required: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    userName: {
      type: String,
      required: true,
    },
    userEmail: {
      type: String,
      required: true,
    },
    action: {
      type: String,
      required: true,
    },
    // No details or performedBy for login/logout
  },
  { timestamps: true }
);

// Create index for faster queries
activitySchema.index({ createdAt: -1 });
activitySchema.index({ userId: 1 });

export default mongoose.models.Activity || mongoose.model('Activity', activitySchema);
